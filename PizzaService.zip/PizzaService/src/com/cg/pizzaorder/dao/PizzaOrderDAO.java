package com.cg.pizzaorder.dao;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.util.PizzaOrderUtil;

public class PizzaOrderDAO implements IPizzaOrderDAO {
	PizzaOrder pizzaOrder;
	Customer customer;
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		  customer.setCustomerId(PizzaOrderUtil.getCustomer_ID_COUNTER());
		    return PizzaOrderUtil.getOrder_ID_COUNTER();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		System.out.println("CustomerName :"+ customer.getCustName());
        System.out.println("Address of Customer :"+ customer.getAddress());
        System.out.println("Phone Number of Customer :"+ customer.getPhone());
        System.out.println("CustomerId :"+ customer.getCustomerId());
        System.out.println("CustomerName :"+ pizzaOrder.getOrderId());
        return pizzaOrder;
	}


}
