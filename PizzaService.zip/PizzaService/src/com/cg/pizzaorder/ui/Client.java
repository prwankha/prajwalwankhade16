package com.cg.pizzaorder.ui;

import java.util.Scanner;

import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {


	public static  int choice;

	public static void main(String[] args) {
		IPizzaOrderService IpizzaOrderService = new PizzaOrderService();
		Scanner sc=new Scanner(System.in);
		System.out.println("Pizza Order");
		int ch,customerId = 0,price,pizzaTopping,orderDate;
		do {
			System.out.println("1.Place Order");
			System.out.println("2.Display Order");
			System.out.println("3.Exit");
			System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch(ch) {
			case 1:
			
				String custName, address, phone;
				System.out.print("Enter customer Name :");
				custName=sc.next();
				System.out.println("Enter customer address : ");
				address=sc.next();
				System.out.println("Enter customer phone number : ");
				phone=sc.next();
				System.out.println("Type of Pizza Topping preffered : ");
				pizzaTopping=sc.nextInt();
				System.out.println("Price : ");
				price = sc.nextInt();
				System.out.println("Order Date : ");
				orderDate=sc.nextInt();
				break;
			case 2:
				
				System.out.println("Pizza order sucessfully place with order id : "+customerId);
			case 3:
				System.out.println("Exit");	
				System.exit(0);
				break;
			}
		}while(ch!=3);
		}
		
		
	}



