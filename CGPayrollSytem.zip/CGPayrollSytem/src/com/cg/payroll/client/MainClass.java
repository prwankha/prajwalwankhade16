//payroll
package com.cg.payroll.client;

import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.*;

public class MainClass {
	public static void main(String[] args) {

		PayrollServices payrollServices = new PayrollServicesImpl();
		Scanner scanner = new Scanner(System.in);
		int associateId;

		int choice = 0;
		System.out.println("Associate Management System");
		do {
			System.out.println(
					"___________________\nPlease enter ur choice : \n1. Add associate \n2. Find associate \n3. Calculate salary \n4. Display all assocciates \n5. Exit \n___________________");
			choice = scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter new associate details : ");
				System.out.println("First Name : ");
				String firstName = scanner.nextLine();
				System.out.println("Last Name : ");
				String lastName = scanner.nextLine();
				System.out.println("Department : ");
				String department = scanner.nextLine();
				System.out.println("Designation : ");
				String designation = scanner.nextLine();
				System.out.println("Pancard no. : ");
				String pancard = scanner.nextLine();
				System.out.println("Email Id : ");
				String emailId = scanner.nextLine();
				System.out.println("Basic Salary : ");
				int basicSalary = scanner.nextInt();
				System.out.println("EPF Amount : ");
				int epf = scanner.nextInt();
				System.out.println("Company PF Amount :");
				int companyPf = scanner.nextInt();
				System.out.println("Yearly Investment Under 80C : ");
				int yearlyInvestmentUnder80C = scanner.nextInt();
				System.out.println("Bank Account no. :");
				int accountNumber = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Bank Name : ");
				String bankName = scanner.nextLine();
				System.out.println("Bank IFSC Code : ");
				String ifscCode = scanner.nextLine();
				associateId = payrollServices.acceptAssociate(yearlyInvestmentUnder80C, firstName, lastName, department,
						designation, pancard, emailId, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
				try {
					System.out.println(
							"Associate details : \n" + payrollServices.getAssociateDetails(associateId).toString());
				} catch (AssociateDetailsNotFoundException e1) {
					e1.printStackTrace();
				}
				break;

			case 2:
				System.out.println("Enter Associate Id to search");
				associateId = scanner.nextInt();
				try {
					System.out.println(
							"Associate details : \n" + payrollServices.getAssociateDetails(associateId).toString());
				} catch (AssociateDetailsNotFoundException e) {
					e.printStackTrace();
				}
				break;

			case 3:
				System.out.println("Enter Associate Id to calculate salary");
				associateId = scanner.nextInt();
				try {
					System.out.println("Associate salary : " + payrollServices.calculateNetSalary(associateId));
					System.out.println(
							"Associate details : \n" + payrollServices.getAssociateDetails(associateId).toString());
				} catch (AssociateDetailsNotFoundException e) {
					e.printStackTrace();
				}
				break;

			case 4:
				System.out.println("All Associate Details");
				List<Associate> associates = payrollServices.getAllAssociateDetails();
				try {
					for (Associate associate : associates)
						if (associate != null)
							System.out.println("___________________________________________\n"
									+ payrollServices.getAssociateDetails(associate.getAssociateId()).toString());
				} catch (AssociateDetailsNotFoundException e) {
					e.printStackTrace();
				}
				break;

			case 5:
				System.out.println("Exited");
				break;
			default:
				System.out.println("Invalid Choice...");
				break;
			}
		} while (choice != 5);
	}
}