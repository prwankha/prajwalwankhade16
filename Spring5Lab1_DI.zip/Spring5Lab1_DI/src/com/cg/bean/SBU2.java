package com.cg.bean;

public class SBU2 {
	private int sbuId;
	private String sbuName, sbuHead;
	
	public SBU2() {}

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	@Override
	public String toString() {
		return "SBU : \nSBU Id=" + sbuId + "\nSBU Name=" + sbuName + "\nSBU Head=" + sbuHead;
	}
}