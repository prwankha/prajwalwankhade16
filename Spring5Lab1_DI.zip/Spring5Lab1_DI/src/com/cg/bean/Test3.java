package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test3 {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("cg.xml");

		SBU3 sbu=(SBU3) context.getBean("pes3");
		
		System.out.println(sbu);
	}
}