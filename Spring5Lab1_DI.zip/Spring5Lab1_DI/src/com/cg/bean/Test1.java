package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("cg.xml");
		
		Employee1 employee=(Employee1) context.getBean("emp1");
		
		System.out.println(employee);
	}
}