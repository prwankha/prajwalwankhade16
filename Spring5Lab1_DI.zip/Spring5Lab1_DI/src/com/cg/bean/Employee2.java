package com.cg.bean;

public class Employee2 {
	private int employeeId, age;
	private double salary;
	private String employeeName;
	private SBU2 businessUnit;

	public Employee2() {
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public SBU2 getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(SBU2 businessUnit) {
		this.businessUnit = businessUnit;
	}

	@Override
	public String toString() {
		return "Employee Details :\n--------------------------------\nEmployee ID=" + employeeId + "\nAge=" + age
				+ "\nSalary=" + salary + "\nEmployee Name=" + employeeName + "\n\nBusiness Unit=" + businessUnit;
	}
}