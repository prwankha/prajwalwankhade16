package com.cg.bean;

import java.util.List;

public class SBU3 {
	private int sbuId;
	private String sbuName, sbuHead;
	private List<Employee3> employee3s;

	public SBU3() {
	}

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public List<Employee3> getEmployee3s() {
		return employee3s;
	}

	public void setEmployee3s(List<Employee3> employee3s) {
		this.employee3s = employee3s;
	}

	@Override
	public String toString() {
		return "SBU3 : \nSBU ID=" + sbuId + "\nSBU Name=" + sbuName + "\nSBU Head=" + sbuHead + "\nEmployees="
				+ employee3s;
	}
}