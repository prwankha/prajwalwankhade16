package com.cg.inherit.beans;

public final class SalesManager extends Pemploye{
   private int commision,noOfSales;

public SalesManager() {
	super();
	
}

public SalesManager(int employeId, int totalSalary, int basicSalary, String firstName, String lastName,int noOfSales) {
	super(employeId, totalSalary, basicSalary, firstName, lastName);
	this.noOfSales=noOfSales;
}

public int getCommision() {
	return commision;
}

public void setCommision(int commision) {
	this.commision = commision;
}

public int getNoOfSales() {
	return noOfSales;
}

public void setNoOfSales(int noOfSales) {
	this.noOfSales = noOfSales;
}


public void calculateSalary() {
	this.commision=noOfSales*100;
	super.calculateSalary();
	this.setTotalSalary(this.getTotalSalary()+commision);
}

@Override
public String toString() {
	return super.toString()+ commision + ", noOfSales=" + noOfSales ;
}

}
   
   

