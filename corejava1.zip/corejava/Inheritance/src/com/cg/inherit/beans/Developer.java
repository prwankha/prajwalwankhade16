package com.cg.inherit.beans;

public final class Developer extends Pemploye{
	private int noOfProject,incentive;

	public Developer() {
		super();
		
	}

	public Developer(int employeId, int totalSalary, int basicSalary, String firstName, String lastName, int noOfProject) {
		
		this.noOfProject=noOfProject;
	}

	public int getNoOfProject() {
		return noOfProject;
	}

	public void setNoOfProject(int noOfProject) {
		this.noOfProject = noOfProject;
	}

	public int getIncentive() {
		return incentive;
	}

	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}


	public void calculateSalary() {
		this.incentive=noOfProject*200;
		super.calculateSalary();
		this.setTotalSalary(this.getTotalSalary()+incentive);
	}

	@Override
	public String toString() {
		return super.toString()+ noOfProject + ", incentive=" + incentive;
	}
	
}