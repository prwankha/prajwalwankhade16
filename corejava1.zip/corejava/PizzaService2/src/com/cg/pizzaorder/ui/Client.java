package com.cg.pizzaorder.ui;

import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.util.PizzaOrderUtil;
public class Client {
	public static void main(String[] args) {
		IPizzaOrderService iPizzaOrderService = new PizzaOrderService();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Pizza Order");
		int ch,orderId,price=350,topping,customerId;
		String customerName, address, phone,orderDate;
		do {
			System.out.println("\n\n1.Place Order");
			System.out.println("2.Display Order");
			System.out.println("3.Exit");
			System.out.println("Enter your choice:");
			ch=scanner.nextInt();
		    scanner.nextLine();
			switch(ch) {
			case 1:
				System.out.print("Enter customer Name :");
				customerName=scanner.nextLine();
				System.out.println("Enter customer address : ");
				address=scanner.nextLine();
 				System.out.println("Enter customer phone number : ");
				phone=scanner.nextLine();
				System.out.println("Enter topping option : ");
				System.out.println("1. Capsicum \n 2. Mushroom \n 3. Jalapeno \n 4. Paneer");
				topping = scanner.nextInt();
				if( topping == 1)
					price+=30;
				else if(topping == 2)
					price+=50;
				else if( topping == 3)
					price+=70;
				else if( topping == 4)
					price+=85;
				try {
					orderId=iPizzaOrderService.placeOrder(customerName, address, phone,price);
					System.out.print("Order is successfully placed with orderId : "+orderId);
				} catch (PizzaException e) {
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("Enter Order id : ");
				orderId = scanner.nextInt();
				try {
					PizzaOrder pizza = iPizzaOrderService.getOrderDetails(orderId);
					customerId = pizza.getCustomerId();
					Customer customer = PizzaOrderUtil.customerEntry.get(customerId);
					System.out.println("customer name : "+customer.getCustName());
					System.out.println("customer Address : "+customer.getAddress());
					System.out.println("customer phone : "+customer.getPhone());
					System.out.println("Total price : "+pizza.getTotalPrice());
					
				} catch (PizzaException e) {
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Exit");	
				System.exit(0);
				break;
			}
		}while(ch!=3);
		}
		
		
	}



