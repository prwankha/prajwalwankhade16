package com.cg.impulse.client;
import java.util.Scanner;

import com.cg.impulse.beans.*;
import com.cg.impulse.services.AssociateServices;

public class MainClass {
	public static void main(String args[]) {
		AssociateServices associateServices = new AssociateServices();
		Scanner sc=new Scanner(System.in);
		int inTime,outTime,associateId;
		String firstName,lastName;
		int ch;
		do {
			System.out.println("Associate Detail");
			System.out.println("1.Add Associate");
			System.out.println("2.Find Associate");
			System.out.println("3.Display working hours");
			System.out.println("4.Exit");
			System.out.println("Enter your choice:");
			ch = sc.nextInt();
			switch(ch) {
			case 1:
				System.out.print("Enter firstName : ");
				firstName=sc.nextLine();
				System.out.print("\nEnter lastName : ");
				lastName=sc.nextLine();
				System.out.println("Enter registered sucessfully");
				associateId=
				System.out.println("Associate id : "+associateId);
				break;
			case 2:
				System.out.println("Enter associateId to search");
				associateId=sc.nextInt();
				break;
			case 3:
				System.out.println("Enter associateId to display");
				break;
			case 4:
				System.out.println("Exit");	
				System.exit(0);
			
				break;
			}
		}while(ch!=4);
	}

}


