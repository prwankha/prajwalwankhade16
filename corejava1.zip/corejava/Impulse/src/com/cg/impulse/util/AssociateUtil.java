package com.cg.impulse.util;

import java.util.HashMap;

import com.cg.impulse.beans.Associate;

public class AssociateUtil {
public static int ASSOCIATE_ID_COUNTER=100;
public static HashMap<Integer, Associate> associates=new HashMap<>();
public static int getASSOCIATE_ID_COUNTER() {
	return ++ASSOCIATE_ID_COUNTER;
}
}




customer.setCustomerId(PizzaUtil.getOrder_ID_COUNTER());
PizzaUtil.customer[(int)PizzaUtil.getOrder_ID_COUNTER()]= customer;
return PizzaUtil.getOrder_ID_COUNTER();