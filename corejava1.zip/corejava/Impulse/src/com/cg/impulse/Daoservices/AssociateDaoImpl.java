package com.cg.impulse.Daoservices;

import java.util.List;

public class AssociateDaoImpl implements AssociateDao  {

	@Override
	public AssociateDao save(AssociateDao associate) {
		
		return null;
	}

	@Override
	public AssociateDao findOne(int associateId) {
		
		return null;
	

	}

	
	
	
}
