package com.cg.impulse.beans;

public class Associate {
String firstName,lastName;
int inTime,outTime,associateId;
public Associate() {}
public Associate( int inTime, int outTime,int associateId) {
	this.inTime = inTime;
	this.outTime = outTime;
	this.associateId = associateId;
}
public Associate(String firstName, String lastName) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	
	
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public int getInTime() {
	return inTime;
}
public void setInTime(int inTime) {
	this.inTime = inTime;
}
public int getOutTime() {
	return outTime;
}
public void setOutTime(int outTime) {
	this.outTime = outTime;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + associateId;
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + inTime;
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	result = prime * result + outTime;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Associate other = (Associate) obj;
	if (associateId != other.associateId)
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (inTime != other.inTime)
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	if (outTime != other.outTime)
		return false;
	return true;
}
@Override
public String toString() {
	return "Associate [firstName=" + firstName + ", lastName=" + lastName + ", associateId=" + associateId + ", inTime="
			+ inTime + ", outTime=" + outTime + "]";
}

}