package com.cg.banking.bean;

public class Transaction {
	private String transactionID,transactionType,transactionLocation;
	double amount;
	public Transaction(){}
	public Transaction(String transactionID, String transactionType, String transactionLocation, double amount) {
		super();
		this.transactionID = transactionID;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.amount = amount;
	}
	public String getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
}