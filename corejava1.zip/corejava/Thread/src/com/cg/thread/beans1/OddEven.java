package com.cg.thread.beans1;

public class OddEven implements Runnable {

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		try {
			if(t.getName().equals("Even")) {
				for(int i=1;i<=10;i++) {
					if(i%2==0) {
					
					System.out.println(i+"   "+t.getName());
				}
			}
			}
			else if(t.getName().equals("Odd")) {
				for(int i=1;i<=10;i++) {
					if(i%2!=0) {
				
					Thread.sleep(1000);
					System.out.println(i+"   "+t.getName());
				}
			}

			}
		}

		catch (InterruptedException e) {
			e.printStackTrace();
		}




	}
}
