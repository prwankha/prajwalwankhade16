package com.cg.thread.beans;

public class MainClass {
	public static void main(String args[]) {
	RunnableResources runableResource=new RunnableResources();
		Thread th1=new Thread(runableResource,"th1");
		th1.start();
		Thread th2=new Thread(runableResource,"th2");
		th2.start();
			
		
	}

}
