package com.cg.FunctionalDemo;

@FunctionalInterface
public interface FunctionalInterface1 {
public void greetUser(String firstName,String lastName);
}
