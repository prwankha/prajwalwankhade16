package com.cg.FunctionalDemo;

@FunctionalInterface
public interface FunctionalInterface2 {
public int add(int a,int b);
}
