package com.cg.FunctionalDemo;

import java.util.ArrayList;
import java.util.Collection;

public class MainClass {
	public static void main(String args[]) {
		/*FunctionalInterface1 ref1=(firstName,lastName)->System.out.println("GoodMorning" +firstName+ " "+lastName);
		ref1.greetUser("aaa", "bbb");*/

		/*FunctionalInterface2 ref2=(a,b)->a+b;
		System.out.println(ref2.add(100,200));*/

		/*callForWork(()->System.out.println("Hello Raju bhau"));
	}
	public static void callForWork(Service service) {
		service.doSomeWork();
	}

	Runnable resourceResources=()->{
		for(int i=1;i<10;i++)
			System.out.println("Tick"+i);
	};
	Thread th1=new Thread(resourceResources);
	th1.start();

	Thread th2=new Thread()->{
		for(int i=1;i<10;i++)
			System.out.println("Tick"+i);
	}};
	th2.start();*/
		new Thread(()->{
			for(int i=1;i<10;i++)
				System.out.println("Tick"+i);
	}).start();
		
	
	}
	
		
		
		
	}



