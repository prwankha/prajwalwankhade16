package com.cg.inheritance.client;

import com.cg.inheritance.beans.Bike;
import com.cg.inheritance.beans.Car;
import com.cg.inheritance.beans.Vehicle;

public class MainClass {

	public static void main(String[] args) {
		Vehicle v=new Vehicle(1000, 1111, "mh27");
		Car c=new Car(2222, 1234, "mh12", 6, "hondacity", "petrol");
		Bike b=new Bike(11123, 3455, "mh13", "Splender", "hero", "50000");
		System.out.println(c.getCarName());
		System.out.println(c.getLicensePlate());
		System.out.println(v.getLicensePlate());
		System.out.println(c.getModelType());
		System.out.println(b.getBikeCompany());
		

	}

}
