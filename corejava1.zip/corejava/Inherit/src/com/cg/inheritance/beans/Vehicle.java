package com.cg.inheritance.beans;

public class Vehicle {
private int insurance,regNo;
private String licensePlate;
public Vehicle() {}
public Vehicle(int insurance, int regNo, String licensePlate) {
	super();
	this.insurance = insurance;
	this.regNo = regNo;
	this.licensePlate = licensePlate;
}
public int getInsurance() {
	return insurance;
}
public void setInsurance(int insurance) {
	this.insurance = insurance;
}
public int getRegNo() {
	return regNo;
}
public void setRegNo(int regNo) {
	this.regNo = regNo;
}
public String getLicensePlate() {
	return licensePlate;
}
public void setLicensePlate(String licensePlate) {
	this.licensePlate = licensePlate;
}


}