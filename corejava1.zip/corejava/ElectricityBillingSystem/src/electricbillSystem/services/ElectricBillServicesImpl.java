package electricbillSystem.services;

import com.cg.electricbillSystem.bean.Address;
import com.cg.electricbillSystem.bean.Customer;
import com.cg.electricbillSystem.bean.ElectricBill;
import com.cg.electricbillSystem.bean.ElectricityBoard;

public class ElectricBillServicesImpl implements ElectricBillServices{
	

    @Override
    public int acceptUserDetails(String firstName, String lastName, String mobileNo, String emailId, String fatherName,int pincode, String city, String state, String boardName) {
        Customer customer = new Customer(firstName, lastName, mobileNo, emailId, fatherName, new Address(pincode, city, state), new ElectricityBoard(boardName));
        int accountId =0; 
        return accountId;
    }

}
