package com.cg.electricbillSystem.bean;

public class ElectricityBoard {
    private String boardName,rate;
    public ElectricityBoard() {
        super();
    }
    public ElectricityBoard(String boardName) {
        super();
        this.boardName = boardName;
    }
    public ElectricityBoard(String boardName, String rate) {
        super();
        this.boardName = boardName;
        this.rate = rate;
    }
    public String getBoardName() {
        return boardName;
    }
    public void setBoardName(String boardName) {
        this.boardName = boardName;
    }
    public String getRate() {
        return rate;
    }
    public void setRate(String rate) {
        this.rate = rate;
    }
    
}
