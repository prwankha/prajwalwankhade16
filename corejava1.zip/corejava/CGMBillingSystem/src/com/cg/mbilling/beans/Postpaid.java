package com.cg.mbilling.beans;

public class Postpaid {
private  int mobNo;
private Bill bill;
public Postpaid() {}
public Postpaid(int mobNo, Bill bill) {
	super();
	this.mobNo = mobNo;
	this.bill = bill;
}
public int getMobNo() {
	return mobNo;
}
public void setMobNo(int mobNo) {
	this.mobNo = mobNo;
}
public Bill getBill() {
	return bill;
}
public void setBill(Bill bill) {
	this.bill = bill;
}

}


