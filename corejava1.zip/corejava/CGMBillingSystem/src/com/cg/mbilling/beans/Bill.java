package com.cg.mbilling.beans;

public class Bill {
private int billID;
private float totalAmount;
private Address address;
Plan plan;
public Bill() {}
public Bill(int billID, float totalAmount, Address address, Plan plan) {
	super();
	this.billID = billID;
	this.totalAmount = totalAmount;
	this.address = address;
	this.plan = plan;
}
public int getBillID() {
	return billID;
}
public void setBillID(int billID) {
	this.billID = billID;
}
public float getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(float totalAmount) {
	this.totalAmount = totalAmount;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Plan getPlan() {
	return plan;
}
public void setPlan(Plan plan) {
	this.plan = plan;
}

}
