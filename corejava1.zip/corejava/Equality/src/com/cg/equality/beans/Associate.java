package com.cg.equality.beans;

public class Associate {
	private String firstName,lastName,associateId;
	private int totalSalary,basicPay;
	public Associate() {}
	public Associate(String firstName, String lastName, String associateId, int totalSalary, int basicPay) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.associateId = associateId;
		this.totalSalary = totalSalary;
		this.basicPay = basicPay;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAssociateId() {
		return associateId;
	}
	public void setAssociateId(String associateId) {
		this.associateId = associateId;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public int getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(int basicPay) {
		this.basicPay = basicPay;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((associateId == null) ? 0 : associateId.hashCode());
		result = prime * result + basicPay;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + totalSalary;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (associateId == null) {
			if (other.associateId != null)
				return false;
		} else if (!associateId.equals(other.associateId))
			return false;
		if (basicPay != other.basicPay)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (totalSalary != other.totalSalary)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [firstName=" + firstName + ", lastName=" + lastName + ", associateId=" + associateId
				+ ", totalSalary=" + totalSalary + ", basicPay=" + basicPay + "]";
	}
	
}