package com.cg.payroll.exception;

public class SQLException extends Exception{
public SQLException() {}

}
