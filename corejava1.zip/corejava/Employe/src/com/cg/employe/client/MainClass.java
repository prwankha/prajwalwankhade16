package com.cg.employe.client;

import com.cg.employe.beans.Associate;
import com.cg.payroll.beans.Bank;
import com.cg.payroll.beans.Salary;

public class MainClass {

	public static void main(String[] args) {
	Associate [] associate=new Associate[5];
	associate[0]=new Associate("prajwal","wanhde",new Salary(22000,100),new Bank(10102,"hdfc"));
	associate[1]=new Associate("pra","wahade",new Salary(23000,500),new Bank(10103,"hdfc"));
	associate[2]=new Associate("praj","wankade",new Salary(21000,400),new Bank(10104,"hdfc"));
	associate[3]=new Associate("prajw","wankh",new Salary(24000,300),new Bank(10105,"hdfc"));
	associate[4]=new Associate("praal","wakhade",new Salary(25000,200),new Bank(10106,"hdfc"));
	for (Associate associate2 : associate) {
		if(associate2.getSalary().getBasicPay()>20000 && associate2.getBankdetail().getBankName()=="hdfc")
			System.out.println(associate2.getfirstName()+associate2.getlastName());
			
	}
	}

}
