package com.cg.doctor.services;
import com.cg.doctor.bean.DoctorAppointment;
import com.cg.doctor.dao.DADaoImpl;
import com.cg.doctor.dao.DoctorAppointmentDao;
public class DoctorAppointmentServiceImpl implements DoctorAppointmentService {
	private DoctorAppointmentDao doctorAppointmentDao=new DADaoImpl();
	@Override
	public int addDoctorAppointmentDetail(DoctorAppointment doctorAppointment) {
		return doctorAppointmentDao.addDoctorAppointmentDetail(doctorAppointment);
	}
	@Override
	public DoctorAppointment getDoctorAppointmentDetail(int appointmentId) {
		return doctorAppointmentDao.getDoctorAppointmentDetail(appointmentId);
	}

}
