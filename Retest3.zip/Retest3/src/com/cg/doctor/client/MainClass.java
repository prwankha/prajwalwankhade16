package com.cg.doctor.client;

import java.util.Scanner;

import com.cg.doctor.bean.DoctorAppointment;
import com.cg.doctor.services.DoctorAppointmentServiceImpl;
import com.cg.doctor.services.DoctorAppointmentService;

public class MainClass {

	public static void main(String[] args) {
		DoctorAppointmentService doctorappointmentService=new DoctorAppointmentServiceImpl();
		Scanner scanner=new Scanner(System.in);
		int choice,age,phoneNo,appointmentId;
		String patientName,emailId,gender,problemName;
		do {
			System.out.println("Enter your choice :");
			System.out.println("1.Book Doctor Appointment");;
			System.out.println("2.View Doctor Appointment");
			System.out.println("3.Exit");
			choice=scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter patientName :");
				patientName=scanner.nextLine();
				System.out.println("Enter phoneNo :");
				phoneNo=scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter emailId :");
				emailId=scanner.nextLine();
				System.out.println("Enter age :");
				age=scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter gender :");
				gender=scanner.nextLine();
				System.out.println("Enter problemName :");
				problemName=scanner.nextLine();
				DoctorAppointment doctorAppointment=new DoctorAppointment(patientName, phoneNo, emailId, age, gender, problemName);
				appointmentId=doctorappointmentService.addDoctorAppointmentDetail(doctorAppointment);
				System.out.println("Your appointment Id  is : "+appointmentId);
				break;
			case 2:
				System.out.println("Enter appointment Id :");
				appointmentId=scanner.nextInt();
				DoctorAppointment appointmentDetail=doctorappointmentService.getDoctorAppointmentDetail(appointmentId);
				System.out.println("Appointment Detail are :"+appointmentDetail.toString());
				break;
			case 3:
				System.out.println("Thank you");
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid choice");
				break;
			}
		}while(choice!=3);		

	}

}
