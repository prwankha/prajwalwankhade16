package com.cg.doctor.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.doctor.bean.DoctorAppointment;

public class DADaoImpl implements DoctorAppointmentDao {
Map<Integer, DoctorAppointment> doctors;
public static int CUSTOMER_ID=1000;
 public DADaoImpl() {
doctors=new HashMap<Integer, DoctorAppointment>();
doctors.put(new Integer(1), new DoctorAppointment("prajwal", 989, "prajwal@fsf", 21, "Male", "lovariya"));
}
	@Override
	public int addDoctorAppointmentDetail(DoctorAppointment doctorAppointment) {
		doctorAppointment.setAppointmentId(++CUSTOMER_ID);
		doctors.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		return doctorAppointment.getAppointmentId();
	}
	@Override
	public DoctorAppointment getDoctorAppointmentDetail(int appointmentId) {
		return doctors.get(new Integer(appointmentId));
	}

}
