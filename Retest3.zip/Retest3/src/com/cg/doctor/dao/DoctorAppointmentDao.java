package com.cg.doctor.dao;

import com.cg.doctor.bean.DoctorAppointment;

public interface DoctorAppointmentDao {
	int addDoctorAppointmentDetail(DoctorAppointment doctorAppointment);
	 DoctorAppointment getDoctorAppointmentDetail(int appointmentId);
}
