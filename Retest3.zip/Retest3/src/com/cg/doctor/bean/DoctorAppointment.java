package com.cg.doctor.bean;

public class DoctorAppointment {
private String patientName,doctorName,appointmentStatus,emailId,gender,problemName;
private int appointmentId,phoneNo,age;
public DoctorAppointment() {}

public DoctorAppointment(String patientName,int phoneNo, String emailId,  int age,String gender, String problemName) {
	super();
	this.patientName = patientName;
	this.emailId = emailId;
	this.gender = gender;
	this.problemName = problemName;
	this.phoneNo = phoneNo;
	this.age = age;
}

public DoctorAppointment(String patientName, String doctorName, String appointmentStatus, String emailId, String gender,
		String problemName, int appointmentId, int phoneNo, int age) {
	super();
	this.patientName = patientName;
	this.doctorName = doctorName;
	this.appointmentStatus = appointmentStatus;
	this.emailId = emailId;
	this.gender = gender;
	this.problemName = problemName;
	this.appointmentId = appointmentId;
	this.phoneNo = phoneNo;
	this.age = age;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public String getDoctorName() {
	return doctorName;
}
public void setDoctorName(String doctorName) {
	this.doctorName = doctorName;
}
public String getAppointmentStatus() {
	return appointmentStatus;
}
public void setAppointmentStatus(String appointmentStatus) {
	this.appointmentStatus = appointmentStatus;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getProblemName() {
	return problemName;
}
public void setProblemName(String problemName) {
	this.problemName = problemName;
}
public int getAppointmentId() {
	return appointmentId;
}
public void setAppointmentId(int appointmentId) {
	this.appointmentId = appointmentId;
}
public int getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(int phoneNo) {
	this.phoneNo = phoneNo;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + age;
	result = prime * result + appointmentId;
	result = prime * result + ((appointmentStatus == null) ? 0 : appointmentStatus.hashCode());
	result = prime * result + ((doctorName == null) ? 0 : doctorName.hashCode());
	result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
	result = prime * result + ((gender == null) ? 0 : gender.hashCode());
	result = prime * result + ((patientName == null) ? 0 : patientName.hashCode());
	result = prime * result + phoneNo;
	result = prime * result + ((problemName == null) ? 0 : problemName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	DoctorAppointment other = (DoctorAppointment) obj;
	if (age != other.age)
		return false;
	if (appointmentId != other.appointmentId)
		return false;
	if (appointmentStatus == null) {
		if (other.appointmentStatus != null)
			return false;
	} else if (!appointmentStatus.equals(other.appointmentStatus))
		return false;
	if (doctorName == null) {
		if (other.doctorName != null)
			return false;
	} else if (!doctorName.equals(other.doctorName))
		return false;
	if (emailId == null) {
		if (other.emailId != null)
			return false;
	} else if (!emailId.equals(other.emailId))
		return false;
	if (gender == null) {
		if (other.gender != null)
			return false;
	} else if (!gender.equals(other.gender))
		return false;
	if (patientName == null) {
		if (other.patientName != null)
			return false;
	} else if (!patientName.equals(other.patientName))
		return false;
	if (phoneNo != other.phoneNo)
		return false;
	if (problemName == null) {
		if (other.problemName != null)
			return false;
	} else if (!problemName.equals(other.problemName))
		return false;
	return true;
}
@Override
public String toString() {
	return "DoctorAppointment [patientName=" + patientName + ", doctorName=" + doctorName + ", appointmentStatus="
			+ appointmentStatus + ", emailId=" + emailId + ", gender=" + gender + ", problemName=" + problemName
			+ ", appointmentId=" + appointmentId + ", phoneNo=" + phoneNo + ", age=" + age + "]";
}

}

