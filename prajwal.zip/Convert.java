public class Convert{
    public static void main(String[] args){
        int n, count = 0, a;
        String x = "";
        n = 109 ;
        while(n > 0){
            a = n % 2;
            if(a == 1){
                count++;
            }
            x = a+""+x;
            n = n/2;
        }
        System.out.println("Binary number:"+x);
       System.out.println("In decimal :"+Integer.parseInt(x,2));
    }
}