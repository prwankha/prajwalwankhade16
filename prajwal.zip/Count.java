public class Count{
	public static void main(String args[]){
		int n=1;
		while(n<=10){
			if(n!=2 && n!=5){
				System.out.print(n+" ");
			}
			n++;
		}
	}
}	