
public class Pattern{
    public static void pattern1(){
        for(int i=1;i<=5;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void pattern2(){
        for(int i=1;i<=5;i++){
            for(int j=5;j>=i;j--){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void pattern3(){
        for(int i=1;i<=5;i++){
            for(int j=5;j>i;j--){
                System.out.print(" ");
            }
            for(int k=1;k<=i;k++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
    public static void pattern4(){
        for(int i=1;i<=5;i++){
            for(int k=1;k<i;k++){
                System.out.print(" ");
            }
            for(int j=5;j>=i;j--){
                System.out.print("*");
            }

            System.out.println();
        }
    }
    public static void main(String[] aa){
   
        Pattern.pattern1();
        System.out.println();
        Pattern.pattern2();
        System.out.println();
        Pattern.pattern3();
        System.out.println();
        Pattern.pattern4();
    }
}
	
