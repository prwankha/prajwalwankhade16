public class ConvertPalindrome{
    public static void main(String[] args){
        int n,num,count=0,a,reversedNum=0,remainder,originalInteger;;
        String x="";
        n = 121;
        num=n;
        originalInteger = n;
        while(n > 0){
            a = n % 2;
            if(a == 1){
                count++;
            }
            x = a+""+x;
            n = n/2;
        }
    System.out.println("Binary number:"+x);
    while( num != 0 )
    {
        remainder = num % 10;
        reversedNum = reversedNum * 10 + remainder;
        num/= 10;
    }
    if (originalInteger == reversedNum)
        System.out.println(originalInteger + " is a palindrome.");
    else
        System.out.println(originalInteger + " is not a palindrome.");
    }
}