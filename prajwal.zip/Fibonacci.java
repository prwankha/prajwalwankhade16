public class Fibonacci{
	public static void main(String args[]){
		int a=0;
		int b=1;
		int c=a+b;
		System.out.print(a);
		System.out.print(b);
		for(int n=1;n<10;n++){
			System.out.print(c+"");
			a=b;
			b=c;
			c=a+b;
			
		}
	}	
}		