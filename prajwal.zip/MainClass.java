class MainClass{
public static void main(String[] str)
{
System.out.println("Hello World");
}
}