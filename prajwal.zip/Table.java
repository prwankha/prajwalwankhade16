public class Table{
	public static void main(String[] str){
		for(int i=1; i<=10; i++)
		{
			int j=i;
			for(int k=1; k<=10; k++)
			{
				System.out.print(j+" ");
				j=j+i;
			}//end 
			System.out.println();
		}//end
	}
}

