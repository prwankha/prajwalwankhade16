public class OddEven{
    public static void main(String[] aa){
        int x=1,y=10;
        for(int i=x;i<=y;i++){
            if(i%2==0)
                System.out.println(i+" is even");
            else
                System.out.println(i+" is odd");
        }
    }
}