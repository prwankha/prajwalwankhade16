package com.cg.inheritance.beans;

public class Bike extends Vehicle{
	private String bikeName,bikeCompany,price;

	public Bike() {
		super();
		
	}

	public Bike(int insurance, int regNo, String licensePlate, String bikeName, String bikeCompany, String price) {
		super(insurance, regNo, licensePlate);
		this.bikeName=bikeName;
		this.bikeCompany=bikeCompany;
		
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public String getBikeCompany() {
		return bikeCompany;
	}

	public void setBikeCompany(String bikeCompany) {
		this.bikeCompany = bikeCompany;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	

}
