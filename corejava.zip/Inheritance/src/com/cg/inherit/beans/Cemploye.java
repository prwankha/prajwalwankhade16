package com.cg.inherit.beans;

public final class Cemploye extends Employe {
	private int hours,variablePay;

	public Cemploye() {
		super();

	}

	public Cemploye(int employeId, int totalSalary, int basicSalary, String firstName, String lastName,int hours) {
		super(employeId, totalSalary, basicSalary, firstName, lastName);
		this.hours=hours;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}
	public void signContract() {
		System.out.println("contract has been signed");
	}
	

	public void calculateSalary() {
		this.variablePay=500;
		this.setTotalSalary(this.hours*variablePay);
	}

	@Override
	public String toString() {
		return super.toString()+ hours + ", variablePay=" + variablePay + "]";
	}
	
}