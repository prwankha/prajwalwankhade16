package com.cg.inherit.client;

import com.cg.inherit.beans.Cemploye;
import com.cg.inherit.beans.Developer;
import com.cg.inherit.beans.Employe;
import com.cg.inherit.beans.Pemploye;
import com.cg.inherit.beans.SalesManager;

public class MainClass {

	public static void main(String[] args) {
		Employe emp;
		
		
	    emp=new Pemploye(123, 15000, 12000, "Tanuj", "Kumar");
		emp.calculateSalary();
		System.out.println(emp.getFirstName()+""+emp.getLastName()+""+emp.getTotalSalary());
		
		emp=new Cemploye(1111, 0, 2234, "aa", "ss", 4);
		Cemploye cemp=(Cemploye)emp;
		cemp.signContract();
		emp.calculateSalary();
		System.out.println(cemp.getFirstName()+""+cemp.getLastName()+""+cemp.getTotalSalary());
		
		emp=new Developer(123, 0, 777, "acd", "cbvb", 2);//upcasting
		Developer demp =(Developer)emp; //downcasting 
		demp.getIncentive();
		emp.calculateSalary();
		System.out.println(emp.getFirstName()+""+emp.getLastName()+""+emp.getTotalSalary());
		SalesManager semp;
	   semp=new SalesManager(222, 0, 1200, "adsd", "SDSGFG",10);
		semp.calculateSalary();
		System.out.println(semp.getFirstName()+""+semp.getLastName()+""+semp.getTotalSalary());
				
				System.out.println(cemp.toString());

	}

}
