package electricbillSystem.services;

import com.cg.electricbillSystem.bean.*;
public interface ElectricBillServices {
    int acceptUserDetails(String firstName, String lastName, String mobileNo, String emailId, String fatherName,int pincode, String city, String state,String boardName);
    
}
