package com.cg.electricbillSystem.bean;

public class ElectricBill {
    private int billId,meterId,fromUnit,toUnit;
    public ElectricBill() {
        super();
    }
    public ElectricBill(int fromUnit,int toUnit) {
        super();
        this.fromUnit = fromUnit;
        this.toUnit = toUnit;
    }
    public ElectricBill(int billId, int meterId, int fromUnit, int toUnit) {
        super();
        this.billId = billId;
        this.meterId = meterId;
        this.fromUnit = fromUnit;
        this.toUnit = toUnit;
    }
    public int getBillId() {
        return billId;
    }
    public void setBillId(int billId) {
        this.billId = billId;
    }
    public int getMeterId() {
        return meterId;
    }
    public void setMeterId(int meterId) {
        this.meterId = meterId;
    }
    public int getFromUnit() {
        return fromUnit;
    }
    public void setFromUnit(int fromUnit) {
        this.fromUnit = fromUnit;
    }
    public int getToUnit() {
        return toUnit;
    }
    public void setToUnit(int toUnit) {
        this.toUnit = toUnit;
    }
    
}
