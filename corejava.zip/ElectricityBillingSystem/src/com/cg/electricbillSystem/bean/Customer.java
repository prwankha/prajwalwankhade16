package com.cg.electricbillSystem.bean;

public class Customer {
    private int accountId;
    private String firstName,lastName,mobileNo,emailId,fatherName;
    private Address address;
    private ElectricBill electricBill;
    private ElectricityBoard electricityBoard;
    public Customer() {
        super();
    }
    public Customer(int accountId) {
        super();
        this.accountId = accountId;
    }
    
    public Customer(String firstName, String lastName, String mobileNo, String emailId, String fatherName,
            Address address, ElectricityBoard electricityBoard) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNo = mobileNo;
        this.emailId = emailId;
        this.fatherName = fatherName;
        this.address = address;
        this.electricityBoard = electricityBoard;
    }
    public Customer(int accountId, String firstName, String lastName, String mobileNo, String emailId,
            String fatherName, Address address, ElectricBill electricBill, ElectricityBoard electricityBoard) {
        super();
        this.accountId = accountId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNo = mobileNo;
        this.emailId = emailId;
        this.fatherName = fatherName;
        this.address = address;
        this.electricBill = electricBill;
        this.electricityBoard = electricityBoard;
    }
    public int getAccountId() {
        return accountId;
    }
    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getMobileNo() {
        return mobileNo;
    }
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getFatherName() {
        return fatherName;
    }
    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }
    public ElectricBill getElectricBill() {
        return electricBill;
    }
    public void setElectricBill(ElectricBill electricBill) {
        this.electricBill = electricBill;
    }
    
}
