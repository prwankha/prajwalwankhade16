package com.cg.mbilling.client;

import com.cg.mbilling.beans.*;

public class MainClass {

	public static void main(String[] args) {
		Address address=new Address("morshi", "MH", "44444", "IN");
		Plan plan= new Plan(111, "unlimited");
		Bill bill=new Bill(1111111, 100.0f, address, plan);
		Postpaid postpaid=new Postpaid(3546535, bill);		
		Customer customer=new Customer(1221, 64445465, 22222, "psw", "wasdd", "asadd", postpaid);
		System.out.println(customer.getCustomerID());
		System.out.println(customer.getFirstName());
		System.out.println(customer.getLastName());
		System.out.println(customer.getPostpaid().getMobNo());
		System.out.println(customer.getPostpaid().getBill().getTotalAmount());
		System.out.println(customer.getPostpaid().getBill().getPlan().getPlanName());



				
	}

}
