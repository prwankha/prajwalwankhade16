package com.cg.pizzaorder.bean;

public class PizzaOrder {
	private int orderId,customerId;
	private double TotalPrice;
	public PizzaOrder() {

	}
	public PizzaOrder(int orderId, int customerId, double totalPrice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		TotalPrice = totalPrice;
	}
	public PizzaOrder(int orderId, double totalPrice) {
		this.orderId = orderId;
		TotalPrice = totalPrice;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return TotalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		TotalPrice = totalPrice;

	}
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId + ", TotalPrice=" + TotalPrice + "]";
	}

}
