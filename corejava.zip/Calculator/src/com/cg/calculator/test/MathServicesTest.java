package com.cg.calculator.test;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.calculator.exceptions.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl1;

public class MathServicesTest {
	private static MathServices mathservices;
	private  int firstInvalidNo,secondInvalidNo,firstvalidNo,secondvalidNo;

	@BeforeClass
	public static void setUpTestEnv() {
		mathservices=new  MathServicesImpl1();

	}

	@Before
	public  void setUpTestData() {
		firstInvalidNo =-200;
		firstvalidNo=200;
		secondInvalidNo=-100;
		secondvalidNo=100;
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testAddForfirstInvalidNo() throws InvalidNumberRangeException {
		mathservices.add(firstInvalidNo, secondvalidNo);
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testAddForsecondInvalidNo() throws InvalidNumberRangeException {
		mathservices.add(firstvalidNo, secondInvalidNo);

	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testAddForBothvalidNo() throws InvalidNumberRangeException {
		int expectedAns=300;
		int actualAns=mathservices.add(firstvalidNo, secondvalidNo);
		Assert.assertEquals(expectedAns,actualAns);
	}




	@Test(expected=InvalidNumberRangeException.class )
	public void testSubForfirstInvalidNo() throws InvalidNumberRangeException {
		mathservices.sub(firstInvalidNo, secondvalidNo);
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testSubForsecondInvalidNo() throws InvalidNumberRangeException {
		mathservices.sub(firstvalidNo, secondInvalidNo);

	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testSubForBothvalidNo() throws InvalidNumberRangeException {
		int expectedAns=100;
		int actualAns=mathservices.sub(firstvalidNo, secondvalidNo);
		Assert.assertEquals(expectedAns,actualAns);
	}



	@Test(expected=InvalidNumberRangeException.class )
	public void testMulForfirstInvalidNo() throws InvalidNumberRangeException {
		mathservices.mul(firstInvalidNo, secondvalidNo);
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testMulForsecondInvalidNo() throws InvalidNumberRangeException {
		mathservices.mul(firstvalidNo, secondInvalidNo);

	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testMulForBothvalidNo() throws InvalidNumberRangeException {
		int expectedAns=20000;
		int actualAns=mathservices.mul(firstvalidNo, secondvalidNo);
		Assert.assertEquals(expectedAns,actualAns);
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testDivForfirstInvalidNo() throws InvalidNumberRangeException {
		mathservices.div(firstInvalidNo, secondvalidNo);
	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testDivForsecondInvalidNo() throws InvalidNumberRangeException {
		mathservices.div(firstvalidNo, secondInvalidNo);

	}

	@Test(expected=InvalidNumberRangeException.class )
	public void testDivForBothvalidNo() throws InvalidNumberRangeException {
		int expectedAns=2;
		int actualAns=mathservices.div(firstvalidNo, secondvalidNo);
		Assert.assertEquals(expectedAns,actualAns);

	}
	@AfterClass
	public static void tearDownTestEnv() {
		mathservices=null;		
	}

	@AfterClass
	public static void tearDownTestData() {
				
	}

}



