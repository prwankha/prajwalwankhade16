class Bike{  
  void run(){
	  System.out.println("I m a bike");
	  }  
}  
class Splendor extends Bike{  
		void run() {			
				System.out.println("running safely with 60km");
		}		  
  
  public static void main(String args[]){  
	  Bike b1= new Bike();
    Bike b2= new Splendor();
    b1.run();
    b2.run();
    
  }  
}  