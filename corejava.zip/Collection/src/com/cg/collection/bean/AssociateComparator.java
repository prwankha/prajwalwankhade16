package com.cg.collection.bean;

import java.util.Comparator;

public class AssociateComparator implements Comparator<Associate> {

	@Override
	public int compare(Associate asc1, Associate asc2) {
		return asc1.getAssociateId()-asc2.getAssociateId();
	}



	
	

}


