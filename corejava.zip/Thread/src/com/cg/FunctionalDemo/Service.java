package com.cg.FunctionalDemo;


public interface Service {
	
void doSomeWork();	

}
