package com.cg.thread.beans1;

public class MyThread extends Thread {

}
