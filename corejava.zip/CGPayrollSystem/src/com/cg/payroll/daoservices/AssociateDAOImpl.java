package com.cg.payroll.daoservices;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;

public class AssociateDAOImpl implements AssociateDAO{
    
    @Override
    public Associate save(Associate associate) {
        associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
        return associate;
    }
    @Override
    public boolean update(Associate associate) {
    	return false;
    }
    @Override
    public Associate findOne(int associateId) {
    	for(Associate associate:PayrollUtil.associate)
    		if(associate!=null && associate.getAssociateID()==associateId)
    			return associate;
        return null;
    }
    @Override
    public Associate[] findAll() {
        return null;
    }

}
