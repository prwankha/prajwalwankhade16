package com.cg.payroll.beans;

public class Salary {
	public int basicpay,pf,epf,hra,pa,ca,oa,annualSalary,grossSalary,mothlyGross,totalSalary;

	public Salary() {
		super();
	}
	
	

	public Salary(int basicpay, int pf, int epf) {
		super();
		this.basicpay = basicpay;
		this.pf = pf;
		this.epf = epf;
	}



	public Salary(int basicpay, int pf, int epf, int hra, int pa, int ca, int oa, int annualSalary, int grossSalary,
			int mothlyGross) {
		super();
		this.basicpay = basicpay;
		this.pf = pf;
		this.epf = epf;
		this.hra = hra;
		this.pa = pa;
		this.ca = ca;
		this.oa = oa;
		this.annualSalary = annualSalary;
		this.grossSalary = grossSalary;
		this.mothlyGross = mothlyGross;
		this.totalSalary=totalSalary;
	}
	
	
	public int getBasicpay() {
		return basicpay;
	}

	public void setBasicpay(int basicpay) {
		this.basicpay = basicpay;
	}

	public int getPf() {
		return pf;
	}

	public void setPf(int pf) {
		this.pf = pf;
	}

	public int getEpf() {
		return epf;
	}

	public void setEpf(int epf) {
		this.epf = epf;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getPa() {
		return pa;
	}

	public void setPa(int pa) {
		this.pa = pa;
	}

	public int getCa() {
		return ca;
	}

	public void setCa(int ca) {
		this.ca = ca;
	}

	public int getOa() {
		return oa;
	}

	public void setOa(int oa) {
		this.oa = oa;
	}

	public int getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(int annualSalary) {
		this.annualSalary = annualSalary;
	}

	public int getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(int grossSalary) {
		this.grossSalary = grossSalary;
	}

	public int getMothlyGross() {
		return mothlyGross;
	}

	public void setMothlyGross(int mothlyGross) {
		this.mothlyGross = mothlyGross;
	}

	public int gettotalSalary() {
		return totalSalary;
	}

	public void settotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;

}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + annualSalary;
		result = prime * result + basicpay;
		result = prime * result + ca;
		result = prime * result + epf;
		result = prime * result + grossSalary;
		result = prime * result + hra;
		result = prime * result + mothlyGross;
		result = prime * result + oa;
		result = prime * result + pa;
		result = prime * result + pf;
		result = prime * result + totalSalary;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (annualSalary != other.annualSalary)
			return false;
		if (basicpay != other.basicpay)
			return false;
		if (ca != other.ca)
			return false;
		if (epf != other.epf)
			return false;
		if (grossSalary != other.grossSalary)
			return false;
		if (hra != other.hra)
			return false;
		if (mothlyGross != other.mothlyGross)
			return false;
		if (oa != other.oa)
			return false;
		if (pa != other.pa)
			return false;
		if (pf != other.pf)
			return false;
		if (totalSalary != other.totalSalary)
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Salary [basicpay=" + basicpay + ", pf=" + pf + ", epf=" + epf + ", hra=" + hra + ", pa=" + pa + ", ca="
				+ ca + ", oa=" + oa + ", annualSalary=" + annualSalary + ", grossSalary=" + grossSalary
				+ ", mothlyGross=" + mothlyGross + ", totalSalary=" + totalSalary + "]";
	}
	

}
