package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollservices.PayrollServices;
import com.cg.payroll.payrollservices.PayrollServicesImpl;
import com.cg.payroll.util.PayrollUtil;



public class Associatetest {
	private static PayrollServices payrollServices;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices =new PayrollServicesImpl(); 
	}
	
	@Before
	public void setUpTestData() {
		Associate associate=new Associate(101, 8000, "p", "w", "cse", "analyst1", "adsda", "asddf", new Salary(30000, 1000, 1000), new BankDetails(12121, "asd23", "hdfc"));
		Associate associate1=new Associate(102, 9000, "w", "p", "cse", "analyst2", "adersda", "aegddf", new Salary(40000, 1500, 1500), new BankDetails(12122, "asd24", "hdfc"));
		PayrollUtil.associates.put(associate.getAssociateID(), associate);
		PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
		PayrollUtil.ASSOCIATE_ID_COUNTER=103;
		
	}

	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testAcceptAssociataeDetailForInvalidData() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(84);
	}
	
	
	@Test
	public void testAcceptAssociataeDetailForValidData() {
		int expectedAssociateId=104;
		int actualAssoicateId=payrollServices.acceptAssociatedetails("AA", "WW", 6000, "bbbb", "a5", "12345", "dfsfg", 10000, 100, 100, 1234588, "afddf35", "hdfc");
		Assert.assertEquals(expectedAssociateId, actualAssoicateId);
	
	}
	
		@After
		public void tearDownTestData() {
			PayrollUtil.ASSOCIATE_ID_COUNTER=100;
			PayrollUtil.associates.clear();
			
			}
		@AfterClass
		public static void tearDownTestEnv() {
			payrollServices=null;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

}
